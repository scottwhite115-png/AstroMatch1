# Daily Standup Template

## 📅 Date: [Today's Date]

## 🎯 Yesterday's Accomplishments
- [ ] Task 1
- [ ] Task 2
- [ ] Task 3

## 🎯 Today's Goals
- [ ] Task 1
- [ ] Task 2
- [ ] Task 3

## 🚨 Blockers/Issues
- [ ] Issue 1
- [ ] Issue 2

## 📊 Progress Update
- **Sprint Progress**: X% complete
- **Tasks Completed**: X of Y
- **Next Priority**: [Next task]

## 💡 Notes
- Any additional notes or insights
