# Discovery (Potential Matches)

## 📝 Description
**Goal:** Swipe/Tap UI; overlays per photo; pass=4-week cooldown; like=mutual→match. **Steps** - Card stack with photo carousel: - Tap left/right to change photos - Swipe right=Like; Swipe left=Pass - Overlay content by photo index: - Photo 1: Name • East–West signs • Compatibility % - Photo 2: Job title • City • Profession • Relationship goals - Photo 3: Hobbies & Interests - Photo 4: Favorite foods - Photo 5: Favorite music - Photo 6: Have/want children **Acceptance**

## ✅ Tasks


## 🎯 Acceptance Criteria


## 📊 Progress
- **Total Tasks**: 0
- **Completed**: 0
- **In Progress**: 0
- **Pending**: 0

## 🚀 Next Actions
1. Review task list
2. Prioritize by importance
3. Start with first task
4. Update progress regularly
