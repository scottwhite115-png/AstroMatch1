"use client"

import { useRouter } from "next/navigation"
import { useTheme } from "@/contexts/ThemeContext"
import { chinesePairBlurbs, cnKey } from "@/lib/chinesePairBlurbs"
import { getChinesePattern } from "@/lib/chinesePatternSystem"
import { patternDefinitions } from "@/lib/chinesePatternSystem"
import type { ChineseAnimal } from "@/lib/chinesePairBlurbs"
import { getCompatibilityTable } from "@/lib/chineseCompatibilityTable"

const FourPointedStar = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" />
  </svg>
)

export default function RatPage() {
  const router = useRouter()
  const { theme, setTheme } = useTheme()

  return (
    <div
      className={`${theme === "light" ? "bg-white" : "bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900"} astrology-page min-h-screen w-full relative pb-24`}
    >
      <div className="relative z-10">
        <div className="px-3 pt-2 pb-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-0.5">
              <FourPointedStar className="w-4 h-4 text-orange-500" />
              <span className="font-bold text-base bg-gradient-to-r from-orange-600 via-orange-500 to-red-500 bg-clip-text text-transparent">
                AstroLibrary
              </span>
            </div>
            
            {/* Theme Toggle Button */}
            <button
              onClick={() => setTheme(theme === "light" ? "dark" : "light")}
              className={`p-2 rounded-lg transition-colors ${theme === "light" ? "hover:bg-gray-100" : "hover:bg-white/10"}`}
              aria-label="Toggle theme"
            >
              {theme === "light" ? (
                <svg className="w-5 h-5 text-gray-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
                </svg>
              ) : (
                <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="5" />
                  <line x1="12" y1="1" x2="12" y2="3" />
                  <line x1="12" y1="21" x2="12" y2="23" />
                  <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
                  <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
                  <line x1="1" y1="12" x2="3" y2="12" />
                  <line x1="21" y1="12" x2="23" y2="12" />
                  <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
                  <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
                </svg>
              )}
            </button>
          </div>
        </div>

        <div className="px-4 pt-2 pb-3 sm:px-6 lg:px-8">
          {/* Header with Back Button */}
          <div className="flex items-center gap-3 mb-6">
            <button
              onClick={() => router.back()}
              className={`p-2 rounded-lg transition-colors ${theme === "light" ? "hover:bg-gray-100" : "hover:bg-white/10"}`}
              aria-label="Go back"
            >
              <svg 
                className={`w-6 h-6 ${theme === "light" ? "text-gray-700" : "text-white"}`}
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2"
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <path d="m15 18-6-6 6-6"/>
              </svg>
            </button>
            <div className="flex items-center gap-3">
              <span className="text-4xl">🐀</span>
              <h1 className={`text-2xl font-bold ${theme === "light" ? "text-gray-900" : "text-white"}`}>
                Rat
              </h1>
            </div>
          </div>

          {/* Content */}
          <div className={`space-y-6 ${theme === "light" ? "text-gray-800" : "text-white/80"}`}>
            <div className={`text-sm ${theme === "light" ? "text-gray-600" : "text-white/60"}`}>
              Year of Birth examples: 1960, 1972, 1984, 1996, 2008, 2020
            </div>

            <div>
              <p className={`text-sm font-semibold mb-2 ${theme === "light" ? "text-gray-700" : "text-white/70"}`}>
                Element: Yang Water | Trine: Visionaries (Rat, Dragon, Monkey)
              </p>
            </div>

            <div>
              <h2 className={`text-xl font-bold mb-3 ${theme === "light" ? "text-gray-900" : "text-white"}`}>
                Core Personality
              </h2>
              <div className="space-y-3">
                <p>
                  Rats are clever, quick-thinking, and resourceful — born strategists who can see opportunity in chaos. Their energy is alert, flexible, and observant; they're rarely caught unprepared. Charming and witty, Rats are natural communicators who can adapt to any crowd while quietly assessing motives and odds. They like comfort and security yet are also ambitious, always planning the next step ahead.
                </p>
                <p>
                  Their Water nature makes them intuitive and emotionally perceptive, but also prone to nervous tension when juggling too many priorities. They value intellect, humour, and efficiency, often preferring subtle influence to overt confrontation. Beneath their sociable exterior lies a calculating mind that thrives on information, networks, and contingency plans.
                </p>
              </div>
            </div>

            <div>
              <h2 className={`text-xl font-bold mb-3 ${theme === "light" ? "text-gray-900" : "text-white"}`}>
                Relationships
              </h2>
              <div className="space-y-3">
                <p>
                  In relationships, the Rat is lively, affectionate, and surprisingly romantic when trust is earned. They enjoy playful banter, shared curiosity, and mental connection. Loyalty matters, but so does mental stimulation — they need partners who keep conversation flowing and life interesting.
                </p>
                <p>
                  At times they can be possessive or controlling if security feels threatened, but they are also generous when loved well. Rats tend to attract ambitious or witty partners who mirror their sharpness. They match best with Dragon and Monkey (same Trine) for shared optimism and pace, and with Ox for steadiness and grounding. Their lesson in love is to balance calculation with vulnerability — to trust that emotional honesty can create the stability they crave.
                </p>
              </div>
            </div>

            <div>
              <h2 className={`text-xl font-bold mb-3 ${theme === "light" ? "text-gray-900" : "text-white"}`}>
                Career & Life Path
              </h2>
              <div className="space-y-3">
                <p>
                  Rats excel in environments where intelligence, adaptability, and social skill matter. They're quick learners and persuasive communicators — excellent in business, marketing, politics, finance, journalism, or tech. They manage resources wisely and often climb ladders early through strategic alliances.
                </p>
                <p>
                  They dislike waste and inefficiency, preferring merit-based systems that reward initiative. As leaders, they're pragmatic and attentive to detail, though they must guard against micromanaging. Their financial instincts are strong, and they often build security through multiple ventures or investments. When balanced, the Rat becomes a visionary strategist — smart, creative, and quietly powerful.
                </p>
              </div>
            </div>

            <div>
              <h2 className={`text-xl font-bold mb-3 ${theme === "light" ? "text-gray-900" : "text-white"}`}>
                Compatibility with Other Signs
              </h2>
              <div className="space-y-4">
                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Rat — Same Sign (Self-Punishment Xing 相刑)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Mutual mirrors
                  </p>
                  <p>
                    Two Rats create a quick, mentally sharp bond built on resourcefulness and alert instincts. As a self-punishment Xing (相刑) match, shared anxieties and overthinking can loop back on both of them. The connection is clever and fast-moving, but needs trust and emotional honesty to avoid turning tense or defensive.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Ox — Secret Friend (Liu He 六合)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Quiet alliance
                  </p>
                  <p>
                    Rat and Ox form a Liu He (六合) "secret friend" pairing, grounded in loyalty and practical support. Rat brings strategy and adaptability; Ox offers steadiness and follow-through. The connection feels reliable, quietly protective, and strong for long-term building.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Tiger — Neutral
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Speed vs. impulse
                  </p>
                  <p>
                    Rat's alert, strategic nature meets Tiger's bold, impulsive energy. There's excitement and momentum, but also mismatched pacing and risk tolerance. The bond works best when Tiger respects Rat's caution and Rat trusts Tiger's courage.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Rabbit — Neutral
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Mind and sensitivity
                  </p>
                  <p>
                    Rat and Rabbit form a gentle, thoughtful connection without strong classical harmony. Rabbit brings softness and emotional nuance; Rat brings planning and clear perception. The match feels subtle and calm, thriving with patience and mutual reassurance.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Dragon — Same Trine (San He 三合)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Visionary partners
                  </p>
                  <p>
                    Rat and Dragon share the San He (三合) Visionaries trine, creating a dynamic, high-momentum alliance. Rat contributes strategy and realism; Dragon adds boldness and presence. The relationship often feels driven, focused, and naturally aligned toward big goals.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Snake — Neutral
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Quiet strategists
                  </p>
                  <p>
                    Rat and Snake both value insight and timing, creating a subtle, observant bond. Snake brings depth and intuition; Rat adds agility and practical thinking. The connection feels calm, analytical, and quietly calculating when trust is strong.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Horse — Clash Pair (Liu Chong 六冲)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Restless contrast
                  </p>
                  <p>
                    Rat and Horse form a Liu Chong (六冲) clash pair, where quick mental shifts meet restless physical motion. Horse seeks freedom and spontaneous movement; Rat looks for security and workable plans. The connection can be exciting but unstable, with tension around commitment and pacing.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Goat — Six Harms (Liu Hai 六害)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Uneven comfort
                  </p>
                  <p>
                    Rat and Goat sit in a Liu Hai (六害) pattern, where worry and sensitivity can easily tangle. Goat brings warmth and empathy; Rat brings alertness and problem-solving. Without clear boundaries, the bond may feel draining, with one over-caring and the other over-thinking.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Monkey — Same Trine (San He 三合)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Quick and inventive
                  </p>
                  <p>
                    Rat and Monkey share the San He (三合) Visionaries trine, blending wit, speed, and flexibility. Monkey adds playfulness and improvisation; Rat adds focus and practical drive. The relationship feels lively, clever, and full of shared schemes and ideas.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Rooster — Neutral
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Details and strategy
                  </p>
                  <p>
                    Rat and Rooster form a sharp-eyed, analytical match without formal harmony. Rooster brings precision and directness; Rat brings adaptability and quiet calculation. The bond can feel efficient and capable, but needs tact to avoid criticism and nitpicking.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Dog — Neutral
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Loyal but wary
                  </p>
                  <p>
                    Rat and Dog share loyalty but express it differently. Dog brings principle and moral clarity; Rat brings pragmatism and resourcefulness. The connection feels earnest and observant, working best when they align on values and avoid second-guessing each other.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Pig — Neutral
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Head and heart
                  </p>
                  <p>
                    Rat's strategic mind meets Pig's open-hearted warmth. Pig offers generosity and emotional softness; Rat offers planning and structure. The relationship can feel nurturing and safe when Rat slows down and Pig sets gentle boundaries.
                  </p>
                </div>
              </div>
              
              {/* Compatibility Table */}
              <div className="mt-8">
                <h3 className={`text-lg font-bold mb-4 ${theme === "light" ? "text-gray-900" : "text-white"}`}>
                  Compatibility Summary
                </h3>
                <div className="overflow-x-auto">
                  <table className={`w-full border-collapse ${theme === "light" ? "bg-white" : "bg-slate-800/40 border border-indigo-500/20 shadow-lg shadow-indigo-950/30"} rounded-lg overflow-hidden`}>
                    <thead>
                      <tr className={theme === "light" ? "bg-gray-100" : "bg-slate-900/50"}>
                        <th className={`px-4 py-3 text-left text-sm font-semibold ${theme === "light" ? "text-gray-700" : "text-white"}`}>
                          Pattern
                        </th>
                        <th className={`px-4 py-3 text-left text-sm font-semibold ${theme === "light" ? "text-gray-700" : "text-white"}`}>
                          Partner Animal(s)
                        </th>
                        <th className={`px-4 py-3 text-left text-sm font-semibold ${theme === "light" ? "text-gray-700" : "text-white"}`}>
                          Strength
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {getCompatibilityTable("Rat").map((row, index) => (
                        <tr 
                          key={index}
                          className={`border-t ${theme === "light" ? "border-gray-200" : "border-indigo-500/20"} ${index % 2 === 0 ? (theme === "light" ? "bg-white" : "bg-slate-800/40") : (theme === "light" ? "bg-gray-50" : "bg-slate-900/30")}`}
                        >
                          <td className={`px-4 py-3 text-sm font-medium`} style={{ color: row.color }}>
                            {row.pattern}
                          </td>
                          <td className={`px-4 py-3 text-sm ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                            {row.partners.join(", ")}
                          </td>
                          <td className={`px-4 py-3 text-sm ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                            {row.strength}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

