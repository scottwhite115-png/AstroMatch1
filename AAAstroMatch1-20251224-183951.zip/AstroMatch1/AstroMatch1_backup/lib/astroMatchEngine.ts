export { getMatchLabel, type MatchResult, type PersonSign, type Label } from '@/engine/matchEngine';
