"use client"

import { useRouter } from "next/navigation"
import { useTheme } from "@/contexts/ThemeContext"
import { chinesePairBlurbs, cnKey } from "@/lib/chinesePairBlurbs"
import { getChinesePattern } from "@/lib/chinesePatternSystem"
import { patternDefinitions } from "@/lib/chinesePatternSystem"
import type { ChineseAnimal } from "@/lib/chinesePairBlurbs"
import { getCompatibilityTable } from "@/lib/chineseCompatibilityTable"

const FourPointedStar = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" />
  </svg>
)

export default function RatPage() {
  const router = useRouter()
  const { theme, setTheme } = useTheme()

  return (
    <div
      className={`${theme === "light" ? "bg-white" : "bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900"} astrology-page min-h-screen w-full relative pb-24`}
    >
      <div className="relative z-10">
        <div className="px-3 pt-2 pb-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-0.5">
              <FourPointedStar className="w-4 h-4 text-orange-500" />
              <span className="font-bold text-base bg-gradient-to-r from-orange-600 via-orange-500 to-red-500 bg-clip-text text-transparent">
                AstroMatch
              </span>
            </div>
            
            {/* Theme Toggle Button */}
            <button
              onClick={() => setTheme(theme === "light" ? "dark" : "light")}
              className={`p-2 rounded-lg transition-colors ${theme === "light" ? "hover:bg-gray-100" : "hover:bg-white/10"}`}
              aria-label="Toggle theme"
            >
              {theme === "light" ? (
                <svg className="w-5 h-5 text-gray-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
                </svg>
              ) : (
                <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="5" />
                  <line x1="12" y1="1" x2="12" y2="3" />
                  <line x1="12" y1="21" x2="12" y2="23" />
                  <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
                  <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
                  <line x1="1" y1="12" x2="3" y2="12" />
                  <line x1="21" y1="12" x2="23" y2="12" />
                  <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
                  <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
                </svg>
              )}
            </button>
          </div>
        </div>

        <div className="px-4 pt-2 pb-3 sm:px-6 lg:px-8">
          {/* Header with Back Button */}
          <div className="flex items-center gap-3 mb-6">
            <button
              onClick={() => router.back()}
              className={`p-2 rounded-lg transition-colors ${theme === "light" ? "hover:bg-gray-100" : "hover:bg-white/10"}`}
              aria-label="Go back"
            >
              <svg 
                className={`w-6 h-6 ${theme === "light" ? "text-gray-700" : "text-white"}`}
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2"
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <path d="m15 18-6-6 6-6"/>
              </svg>
            </button>
            <div className="flex items-center gap-3">
              <span className="text-4xl">🐀</span>
              <h1 className={`text-2xl font-bold ${theme === "light" ? "text-gray-900" : "text-white"}`}>
                Rat
              </h1>
            </div>
          </div>

          {/* Content */}
          <div className={`space-y-6 ${theme === "light" ? "text-gray-800" : "text-white/80"}`}>
            <div className={`text-sm ${theme === "light" ? "text-gray-600" : "text-white/60"}`}>
              Year of Birth examples: 1960, 1972, 1984, 1996, 2008, 2020
            </div>

            <div>
              <p className={`text-sm font-semibold mb-2 ${theme === "light" ? "text-gray-700" : "text-white/70"}`}>
                Element: Yang Water | Trine: Visionaries (Rat, Dragon, Monkey)
              </p>
            </div>

            <div>
              <h2 className={`text-xl font-bold mb-3 ${theme === "light" ? "text-gray-900" : "text-white"}`}>
                Core Personality
              </h2>
              <div className="space-y-3">
                <p>
                  Rats are clever, quick-thinking, and resourceful — born strategists who can see opportunity in chaos. Their energy is alert, flexible, and observant; they're rarely caught unprepared. Charming and witty, Rats are natural communicators who can adapt to any crowd while quietly assessing motives and odds. They like comfort and security yet are also ambitious, always planning the next step ahead.
                </p>
                <p>
                  Their Water nature makes them intuitive and emotionally perceptive, but also prone to nervous tension when juggling too many priorities. They value intellect, humour, and efficiency, often preferring subtle influence to overt confrontation. Beneath their sociable exterior lies a calculating mind that thrives on information, networks, and contingency plans.
                </p>
              </div>
            </div>

            <div>
              <h2 className={`text-xl font-bold mb-3 ${theme === "light" ? "text-gray-900" : "text-white"}`}>
                Relationships
              </h2>
              <div className="space-y-3">
                <p>
                  In relationships, the Rat is lively, affectionate, and surprisingly romantic when trust is earned. They enjoy playful banter, shared curiosity, and mental connection. Loyalty matters, but so does mental stimulation — they need partners who keep conversation flowing and life interesting.
                </p>
                <p>
                  At times they can be possessive or controlling if security feels threatened, but they are also generous when loved well. Rats tend to attract ambitious or witty partners who mirror their sharpness. They match best with Dragon and Monkey (same Trine) for shared optimism and pace, and with Ox for steadiness and grounding. Their lesson in love is to balance calculation with vulnerability — to trust that emotional honesty can create the stability they crave.
                </p>
              </div>
            </div>

            <div>
              <h2 className={`text-xl font-bold mb-3 ${theme === "light" ? "text-gray-900" : "text-white"}`}>
                Career & Life Path
              </h2>
              <div className="space-y-3">
                <p>
                  Rats excel in environments where intelligence, adaptability, and social skill matter. They're quick learners and persuasive communicators — excellent in business, marketing, politics, finance, journalism, or tech. They manage resources wisely and often climb ladders early through strategic alliances.
                </p>
                <p>
                  They dislike waste and inefficiency, preferring merit-based systems that reward initiative. As leaders, they're pragmatic and attentive to detail, though they must guard against micromanaging. Their financial instincts are strong, and they often build security through multiple ventures or investments. When balanced, the Rat becomes a visionary strategist — smart, creative, and quietly powerful.
                </p>
              </div>
            </div>

            <div>
              <h2 className={`text-xl font-bold mb-3 ${theme === "light" ? "text-gray-900" : "text-white"}`}>
                Compatibility with Other Signs
              </h2>
              <div className="space-y-4">
                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Rat — Same Sign (Self-Punishment 相刑)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Quick and calculating
                  </p>
                  <p>
                    Two Rats form a quick-witted, perceptive bond full of sharp humour and intuitive recognition. As a self-punishment Xing (相刑) pairing, their shared intensity can turn inward, creating subtle competitiveness or overthinking. Yet the mental chemistry is strong and engaging. The connection feels lively, intelligent, and quietly charged.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Ox — Secret Friend (Liu He 六合)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Smart and steady
                  </p>
                  <p>
                    Rat and Ox share a Liu He (六合) secret-friend harmony known for stability, loyalty, and long-term support. Rat contributes strategy, adaptability, and clever insight; Ox provides steadiness, commitment, and calm strength. Together they form a natural, quietly powerful team. The dynamic feels grounding, reliable, and mutually reinforcing.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Tiger — Neutral
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Nerves and impulse
                  </p>
                  <p>
                    Rat operates through strategy and foresight, while Tiger moves through instinct and boldness. Their contrasting approaches create an energising, unpredictable rhythm. Rat influences Tiger with subtle planning; Tiger adds courage and immediacy to Rat's world. The connection feels spirited, curious, and lightly contrasting.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Rabbit — Break (Po 破)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Fast and soft
                  </p>
                  <p>
                    Rat's intensity contrasts with Rabbit's gentleness in a Po (破) "Break" pattern that creates emotional fragility. Rabbit brings sensitivity and calm; Rat brings structure and sharp perception. Their blend forms a quiet, thoughtful dynamic shaped by care and timing. The connection feels soft, delicate, and emotionally nuanced.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Dragon — Same Trine (San He 三合)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Ambitious and bold
                  </p>
                  <p>
                    Rat and Dragon belong to the San He (三合) visionary trine, creating a dynamic, high-energy, and naturally ambitious pairing. Rat offers strategy and subtle intelligence; Dragon contributes drive, charisma, and bold initiative. Their chemistry inspires movement and mutual elevation. The dynamic feels confident, lively, and strongly aligned.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Snake — Neutral
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Quiet operators
                  </p>
                  <p>
                    Rat and Snake share intuition, subtlety, and a discerning inner world. Snake adds calm insight and emotional depth; Rat contributes mental agility and long-range thinking. Together they create a quiet, perceptive connection built on trust. The dynamic feels refined, intuitive, and quietly strong.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Horse — Clash Pair (Liu Chong 六冲)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Pulling in opposite directions
                  </p>
                  <p>
                    Rat and Horse stand in a Liu Chong (六冲) opposition, where pacing and priorities move in opposite directions. Rat seeks planning, structure, and emotional steadiness; Horse seeks freedom, speed, and open horizons. The interplay can spark quickly yet shift unpredictably. The connection feels charged, restless, and rhythmically contrasting.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Goat — Six Harms (Liu Hai 六害)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Practical vs. tender
                  </p>
                  <p>
                    Rat and Goat fall under the Liu Hai (六害) "Six Harms" pattern, where misunderstandings form easily. Rat's directness and logic can feel sharp to Goat's sensitive nature; Goat's emotional nuance can confuse Rat's practicality. Yet their contrast holds a gentle, creative softness when balanced. The dynamic feels tender, delicate, and quietly complex.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Monkey — Same Trine (San He 三合)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Clever and restless
                  </p>
                  <p>
                    Rat and Monkey share the San He (三合) visionary trine, forming one of the zodiac's quickest, brightest, and most synergistic pairings. Monkey brings inventiveness and spontaneity; Rat brings insight, planning, and strategic brilliance. Together they amplify each other's talents with ease. The connection feels clever, agile, and naturally aligned.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Rooster — Neutral
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Details and tactics
                  </p>
                  <p>
                    Rat's flexible thinking meets Rooster's precision and structured clarity. Rooster brings refinement and focus; Rat adds adaptability and inventive solutions. Their interplay blends detail with strategy in a subtle, complementary way. The dynamic feels sharp, organised, and quietly productive.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Dog — Neutral
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Loyal schemers
                  </p>
                  <p>
                    Rat and Dog share sincerity, intuition, and an underlying desire for loyalty and honesty. Dog brings steadiness and emotional clarity; Rat offers adaptability and strategic support. Their bond forms gradually through trust and consistency. The connection feels warm, genuine, and quietly supportive.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rat × Pig — Neutral
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Warm and resourceful
                  </p>
                  <p>
                    Rat and Pig create a gentle, cooperative pairing shaped by sensitivity and goodwill. Pig offers kindness, emotional openness, and sincerity; Rat brings structure, insight, and problem-solving. Together they form a soft, balanced connection. The dynamic feels nurturing, warm, and easygoing.
                  </p>
                </div>
              </div>
              
              {/* Compatibility Table */}
              <div className="mt-8">
                <h3 className={`text-lg font-bold mb-4 ${theme === "light" ? "text-gray-900" : "text-white"}`}>
                  Compatibility Summary
                </h3>
                <div className="overflow-x-auto">
                  <table className={`w-full border-collapse ${theme === "light" ? "bg-white" : "bg-slate-800/40 border border-indigo-500/20 shadow-lg shadow-indigo-950/30"} rounded-lg overflow-hidden`}>
                    <thead>
                      <tr className={theme === "light" ? "bg-gray-100" : "bg-slate-900/50"}>
                        <th className={`px-4 py-3 text-left text-sm font-semibold ${theme === "light" ? "text-gray-700" : "text-white"}`}>
                          Pattern
                        </th>
                        <th className={`px-4 py-3 text-left text-sm font-semibold ${theme === "light" ? "text-gray-700" : "text-white"}`}>
                          Partner Animal(s)
                        </th>
                        <th className={`px-4 py-3 text-left text-sm font-semibold ${theme === "light" ? "text-gray-700" : "text-white"}`}>
                          Strength
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {getCompatibilityTable("Rat").map((row, index) => (
                        <tr 
                          key={index}
                          className={`border-t ${theme === "light" ? "border-gray-200" : "border-indigo-500/20"} ${index % 2 === 0 ? (theme === "light" ? "bg-white" : "bg-slate-800/40") : (theme === "light" ? "bg-gray-50" : "bg-slate-900/30")}`}
                        >
                          <td className={`px-4 py-3 text-sm ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                            {row.pattern}
                          </td>
                          <td className={`px-4 py-3 text-sm ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                            {row.partners.join(", ")}
                          </td>
                          <td className={`px-4 py-3 text-sm ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                            {row.strength}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

