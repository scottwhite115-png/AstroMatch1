"use client"

import { useRouter } from "next/navigation"
import { useTheme } from "@/contexts/ThemeContext"
import { chinesePairBlurbs, cnKey } from "@/lib/chinesePairBlurbs"
import { getChinesePattern } from "@/lib/chinesePatternSystem"
import type { ChineseAnimal } from "@/lib/chinesePairBlurbs"
import { getCompatibilityTable } from "@/lib/chineseCompatibilityTable"

const FourPointedStar = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" />
  </svg>
)

export default function RabbitPage() {
  const router = useRouter()
  const { theme, setTheme } = useTheme()

  return (
    <div
      className={`${theme === "light" ? "bg-white" : "bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900"} astrology-page min-h-screen w-full relative pb-24`}
    >
      <div className="relative z-10">
        <div className="px-3 pt-2 pb-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-0.5">
              <FourPointedStar className="w-4 h-4 text-orange-500" />
              <span className="font-bold text-base bg-gradient-to-r from-orange-600 via-orange-500 to-red-500 bg-clip-text text-transparent">
                AstroMatch
              </span>
            </div>
            
            {/* Theme Toggle Button */}
            <button
              onClick={() => setTheme(theme === "light" ? "dark" : "light")}
              className={`p-2 rounded-lg transition-colors ${theme === "light" ? "hover:bg-gray-100" : "hover:bg-white/10"}`}
              aria-label="Toggle theme"
            >
              {theme === "light" ? (
                <svg className="w-5 h-5 text-gray-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
                </svg>
              ) : (
                <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="5" />
                  <line x1="12" y1="1" x2="12" y2="3" />
                  <line x1="12" y1="21" x2="12" y2="23" />
                  <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
                  <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
                  <line x1="1" y1="12" x2="3" y2="12" />
                  <line x1="21" y1="12" x2="23" y2="12" />
                  <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
                  <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
                </svg>
              )}
            </button>
          </div>
        </div>

        <div className="px-4 pt-2 pb-3 sm:px-6 lg:px-8">
          {/* Header with Back Button */}
          <div className="flex items-center gap-3 mb-6">
            <button
              onClick={() => router.back()}
              className={`p-2 rounded-lg transition-colors ${theme === "light" ? "hover:bg-gray-100" : "hover:bg-white/10"}`}
              aria-label="Go back"
            >
              <svg 
                className={`w-6 h-6 ${theme === "light" ? "text-gray-700" : "text-white"}`}
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2"
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <path d="m15 18-6-6 6-6"/>
              </svg>
            </button>
            <div className="flex items-center gap-3">
              <span className="text-4xl">🐇</span>
              <h1 className={`text-2xl font-bold ${theme === "light" ? "text-gray-900" : "text-white"}`}>
                Rabbit
              </h1>
            </div>
          </div>

          {/* Content */}
          <div className={`space-y-6 ${theme === "light" ? "text-gray-800" : "text-white/80"}`}>
            <div className={`text-sm ${theme === "light" ? "text-gray-600" : "text-white/60"}`}>
              Year of Birth examples: 1963, 1975, 1987, 1999, 2011, 2023
            </div>

            <div>
              <p className={`text-sm font-semibold mb-2 ${theme === "light" ? "text-gray-700" : "text-white/70"}`}>
                Element: Yin Wood | Trine: Artists (Rabbit, Goat, Pig)
              </p>
            </div>

            <div>
              <h2 className={`text-xl font-bold mb-3 ${theme === "light" ? "text-gray-900" : "text-white"}`}>
                Core Personality
              </h2>
              <div className="space-y-3">
                <p>
                  The Rabbit is gentle, refined, and empathetic. They value peace, beauty, and kindness, preferring diplomacy over confrontation. Intelligent and perceptive, they notice subtleties others overlook. Rabbits dislike loud or aggressive environments, flourishing instead in calm and creative spaces. They have a talent for art, culture, and negotiation. Their social grace hides quiet resilience — they can adapt gracefully while maintaining dignity. However, they may avoid conflict even when it's necessary, learning over time that boundaries can be loving, too.
                </p>
              </div>
            </div>

            <div>
              <h2 className={`text-xl font-bold mb-3 ${theme === "light" ? "text-gray-900" : "text-white"}`}>
                Relationships
              </h2>
              <div className="space-y-3">
                <p>
                  In love, Rabbits are affectionate, considerate, and loyal. They seek emotional security and mutual respect. They want partners who are gentle but capable of protecting them from harshness. They dislike volatility and prefer stable, affectionate bonds. When hurt, they retreat rather than argue. Their best matches are Goat and Pig, who share their sensitivity, and Dog, who offers loyalty. Their relationship lesson is learning to assert their needs instead of always accommodating others.
                </p>
              </div>
            </div>

            <div>
              <h2 className={`text-xl font-bold mb-3 ${theme === "light" ? "text-gray-900" : "text-white"}`}>
                Career & Life Path
              </h2>
              <div className="space-y-3">
                <p>
                  Rabbits thrive in art, fashion, diplomacy, counselling, design, writing, and hospitality — any field requiring grace, strategy, and empathy. They are peacemakers and problem solvers. They work steadily and harmonize teams through tact. Their financial instincts are careful and conservative. As leaders, they value fairness and cooperation. When confident, they become quietly influential builders of harmony.
                </p>
              </div>
            </div>

            <div>
              <h2 className={`text-xl font-bold mb-3 ${theme === "light" ? "text-gray-900" : "text-white"}`}>
                Compatibility with Other Signs
              </h2>
              <div className="space-y-4">
                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rabbit × Rat — Break (Po 破)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Fast and soft
                  </p>
                  <p>
                    Rabbit's sensitivity meets Rat's sharp, strategic nature, creating a connection shaped by contrast. Rat brings clarity and structure, while Rabbit adds emotional nuance and softness. The dynamic feels thoughtful and quietly complex, with a blend of calm intuition and quick insight. The connection moves at a gentle rhythm when both energies align.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rabbit × Ox — Neutral
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Gentle and grounded
                  </p>
                  <p>
                    Rabbit and Ox create a calm, sincere pairing rooted in steadiness and emotional comfort. Ox brings reliability and grounded presence; Rabbit contributes warmth and subtle perception. Together they form a peaceful, understated bond. The connection feels stable, reassuring, and filled with quiet care.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rabbit × Tiger — Neutral
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Edge and gentleness
                  </p>
                  <p>
                    Rabbit's diplomacy balances Tiger's boldness, creating a mix of strength and softness. Tiger offers protection and expressive energy; Rabbit brings calm understanding. Their pace differs, but the relationship forms a gentle equilibrium when attuned. The dynamic feels supportive, tempered, and quietly resilient.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rabbit × Rabbit — Same Sign (Self-Punishment 相刑)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Soft and cautious
                  </p>
                  <p>
                    Two Rabbits form a deeply intuitive, emotionally attuned partnership. As a self-punishment Xing (相刑) match, shared sensitivity can create moments of withdrawal or over-reflection. Yet the connection is naturally tender and attentive. It feels soothing, empathetic, and quietly harmonious when emotional openness is shared.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rabbit × Dragon — Six Damages / Harm (Liu Hai 六害)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Quiet vs. bold
                  </p>
                  <p>
                    Rabbit's caution contrasts with Dragon's bold, expansive nature. Dragon moves with force and ambition, while Rabbit prefers subtlety and emotional safety. The energies may collide in pace and expression but remain compelling in contrast. The dynamic feels dramatic, vivid, and shaped by temperament differences.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rabbit × Snake — Neutral
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Soft and strategic
                  </p>
                  <p>
                    Rabbit and Snake share a subtle emotional depth expressed in different ways. Rabbit brings softness and gentle intuition; Snake brings insight, composure, and quiet intensity. Together they create a private, reflective connection. The bond feels calm, perceptive, and quietly layered.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rabbit × Horse — Break (Po 破)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Calm vs. restless
                  </p>
                  <p>
                    Rabbit's need for steadiness contrasts with Horse's instinctive speed and spontaneity. Horse brings movement and confidence; Rabbit adds emotional awareness and softness. The pairing forms a dynamic rhythm when balance is found. The connection feels active, contrasting, and shaped by pacing differences.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rabbit × Goat — Same Trine (San He 三合)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Gentle support
                  </p>
                  <p>
                    Rabbit and Goat share the San He (三合) Artist trine, creating one of the gentlest harmonies in the zodiac. Both value kindness, sincerity, and emotional ease. The connection is naturally peaceful and nurturing. It feels warm, expressive, and beautifully aligned.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rabbit × Monkey — Neutral
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Soft and sharp
                  </p>
                  <p>
                    Rabbit's calm presence blends with Monkey's lively, inventive energy. Monkey brings spark and movement; Rabbit brings softness and emotional clarity. Together, they create a curious and balanced pairing. The dynamic feels warm, light, and quietly engaging.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rabbit × Rooster — Break (Po 破)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Delicate vs. direct
                  </p>
                  <p>
                    Rabbit and Rooster communicate in contrasting ways: Rabbit with tact, Rooster with precision. Rabbit softens the edges; Rooster sharpens the details. The pairing reveals both friction and clarity through its differences. The connection feels crisp, candid, and shaped by communication style.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rabbit × Dog — Secret Friend (Liu He 六合)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Kind and protective
                  </p>
                  <p>
                    Rabbit and Dog form a Liu He (六合) secret-friend match rooted in loyalty, warmth, and emotional safety. Dog brings sincerity and steadfastness; Rabbit offers gentleness and intuitive care. The bond feels protective, sincere, and deeply trusting. It is one of Rabbit's most effortless and heartfelt connections.
                  </p>
                </div>

                <div>
                  <h3 className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Rabbit × Pig — Same Trine (San He 三合)
                  </h3>
                  <p className={`text-base font-semibold mb-2 ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                    Soft and sweet
                  </p>
                  <p>
                    Rabbit and Pig share the San He (三合) Artist trine, creating harmony through kindness and emotional openness. Pig adds warmth and generosity; Rabbit brings sensitivity and grace. The relationship flows with ease and heartfelt sincerity. The dynamic feels peaceful, affectionate, and beautifully cohesive.
                  </p>
                </div>
              </div>
              
              {/* Compatibility Table */}
              <div className="mt-8">
                <h3 className={`text-lg font-bold mb-4 ${theme === "light" ? "text-gray-900" : "text-white"}`}>
                  Compatibility Summary
                </h3>
                <div className="overflow-x-auto">
                  <table className={`w-full border-collapse ${theme === "light" ? "bg-white" : "bg-slate-800/40 border border-indigo-500/20 shadow-lg shadow-indigo-950/30"} rounded-lg overflow-hidden`}>
                    <thead>
                      <tr className={theme === "light" ? "bg-gray-100" : "bg-slate-900/50"}>
                        <th className={`px-4 py-3 text-left text-sm font-semibold ${theme === "light" ? "text-gray-700" : "text-white"}`}>
                          Pattern
                        </th>
                        <th className={`px-4 py-3 text-left text-sm font-semibold ${theme === "light" ? "text-gray-700" : "text-white"}`}>
                          Partner Animal(s)
                        </th>
                        <th className={`px-4 py-3 text-left text-sm font-semibold ${theme === "light" ? "text-gray-700" : "text-white"}`}>
                          Strength
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {getCompatibilityTable("Rabbit").map((row, index) => (
                        <tr 
                          key={index}
                          className={`border-t ${theme === "light" ? "border-gray-200" : "border-indigo-500/20"} ${index % 2 === 0 ? (theme === "light" ? "bg-white" : "bg-slate-800/40") : (theme === "light" ? "bg-gray-50" : "bg-slate-900/30")}`}
                        >
                          <td className={`px-4 py-3 text-sm ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                            {row.pattern}
                          </td>
                          <td className={`px-4 py-3 text-sm ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                            {row.partners.join(", ")}
                          </td>
                          <td className={`px-4 py-3 text-sm ${theme === "light" ? "text-gray-800" : "text-white/90"}`}>
                            {row.strength}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

