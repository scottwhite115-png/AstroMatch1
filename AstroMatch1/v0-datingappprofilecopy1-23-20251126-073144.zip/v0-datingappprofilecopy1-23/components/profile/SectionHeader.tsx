"use client";

import React from "react";
import { useTheme } from "@/contexts/ThemeContext";

interface SectionHeaderProps {
  label: string;
  icon?: React.ReactNode; // you can pass an emoji or an SVG
}

export function SectionHeader({ label, icon }: SectionHeaderProps) {
  const { theme } = useTheme();
  
  return (
    <div className="mb-2 flex items-center gap-2">
      {/* Icon - no background, just the emoji/icon */}
      <div className="flex items-center justify-center text-xl">
        {icon ?? <span>★</span>}
      </div>

      {/* Label */}
      <div className="flex flex-col">
        <span className={`text-xs font-semibold uppercase tracking-[0.16em] ${
          theme === "light" ? "text-gray-800" : "text-slate-200"
        }`}>
          {label}
        </span>
      </div>
    </div>
  );
}

