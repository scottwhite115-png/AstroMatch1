// src/components/ConnectionBox.tsx

import React from "react";
import { MatchTier } from "@/lib/matchEngine"; // adjust import as needed

const MAX_STARS = 5;

function StarRow({ value }: { value?: number }) {
  if (value == null) return null;
  const filled = Math.round(Math.max(0, Math.min(MAX_STARS, value)));

  return (
    <div className="flex items-center gap-0.5 text-[12px] leading-none text-amber-300">
      {Array.from({ length: MAX_STARS }).map((_, i) => (
        <span key={i}>{i < filled ? "★" : "☆"}</span>
      ))}
    </div>
  );
}

interface ConnectionBoxProps {
  tier: MatchTier;
  score: number;

  // optional tagline like: "Top tier · One of your strongest overall matches."
  patternTagline?: string;

  // sign labels
  westA: string; // "Aquarius"
  eastA: string; // "Monkey"
  westB: string; // "Libra"
  eastB: string; // "Dragon"

  // star ratings (0–5) already looked up from your tables
  // convention: left = West stars, right = Chinese stars
  westStars?: number;
  eastStars?: number;

  // existing lines
  chineseLine: string; // "Monkey × Dragon — San He..."
  westernLine: string; // "Libra × Aquarius — Airy, idealistic..."

  // whatever else you already pass (elements toggle etc.)
  renderElementsToggle?: React.ReactNode;
  renderProfileButton?: React.ReactNode;
}

export function ConnectionBox(props: ConnectionBoxProps) {
  const {
    tier,
    score,
    patternTagline,
    westA,
    eastA,
    westB,
    eastB,
    westStars,
    eastStars,
    chineseLine,
    westernLine,
    renderElementsToggle,
    renderProfileButton,
  } = props;

  return (
    <div className="rounded-2xl bg-slate-900/80 p-3 text-xs sm:p-4 sm:text-sm">
      {/* Line 1 – Label pill + score */}
      <div className="mb-1 flex items-center justify-between gap-3">
        {/* Rank pill – keep your existing gradient / color logic here */}
        <div className="inline-flex items-center rounded-full px-2 py-1 text-[11px] font-semibold uppercase tracking-wide text-slate-50">
          {tier}
        </div>

        <div className="text-[11px] font-semibold text-slate-200">
          {score}
          <span className="text-slate-400"> / 100</span>
        </div>
      </div>

      {/* Line 2 – Tagline (optional) */}
      {patternTagline && (
        <p className="mb-2 text-[11px] leading-snug text-slate-300 sm:text-xs">
          {patternTagline}
        </p>
      )}

      {/* Line 3 – Sign combo */}
      <p className="mb-1 font-semibold text-slate-100">
        {westA} / {eastA} × {westB} / {eastB}
      </p>

      {/* Line 4 – Stars under each side (left = West pair, right = Chinese pair) */}
      {(westStars != null || eastStars != null) && (
        <div className="mb-2 grid grid-cols-2">
          <div className="flex justify-start">
            <StarRow value={westStars} />
          </div>
          <div className="flex justify-end">
            <StarRow value={eastStars} />
          </div>
        </div>
      )}

      {/* Chinese pattern line */}
      <p className="mb-1 text-slate-200">{chineseLine}</p>

      {/* Western element/relationship line */}
      <p className="mb-2 text-slate-200">{westernLine}</p>

      {/* Footer row: elements toggle & profile button (if provided) */}
      {(renderElementsToggle || renderProfileButton) && (
        <div className="mt-1 flex items-center justify-between gap-3">
          {renderElementsToggle ?? <span />}
          {renderProfileButton}
        </div>
      )}
    </div>
  );
}
